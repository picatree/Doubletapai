let video;
let poseNet;
let poses = [];

let barletWidth = 1.5; // in inches
let ballDiameter = 9.5; // in inches
let doubletapThreshold = 5; //5 in pixels
let doubletapCount = 0;
let trickCount = 0;
let dribbleTime = 0;

let resetButton;
let frontCameraButton;
let backCameraButton;
let currentCamera = "user";

let errorDiv;


function setup() {
createCanvas(640, 480);

let canvasContainer = document.getElementById("canvas-container");
let canvas = createCanvas(640, 480);
canvas.parent(canvasContainer);

let resetButton = document.getElementById("reset-button");
let frontCameraButton = document.getElementById("front-camera-button");
let backCameraButton = document.getElementById("back-camera-button");
  
video = createCapture({
audio: false,
video: {
facingMode: currentCamera
}
}, function() {
console.log("Webcam ready");
});
video.size(width, height);

poseNet = ml5.poseNet(video, modelReady);
poseNet.on("pose", function(results) {
poses = results;
});

resetButton = createButton("Reset");
resetButton.mousePressed(reset);

frontCameraButton = createButton("Switch to Front Camera");
frontCameraButton.mousePressed(function() {
currentCamera = "user";
switchCamera();
});

backCameraButton = createButton("Switch to Back Camera");
backCameraButton.mousePressed(function() {
currentCamera = "environment";
switchCamera();
});

errorDiv = createDiv("");
}

function modelReady() {
console.log("PoseNet model ready");
}

function switchCamera() {
video.remove();
poseNet.removeAllListeners();

video = createCapture({
audio: false,
video: {
facingMode: currentCamera
}
}, function() {
console.log("Webcam ready");
});
video.size(width, height);

poseNet = ml5.poseNet(video, modelReady);
poseNet.on("pose", function(results) {
poses = results;
});
}

function reset() {
doubletapCount = 0;
trickCount = 0;
dribbleTime = 0;
}

function draw() {
background(220);

image(video, 0, 0, width, height);

if (poses.length > 0) {
let pose = poses[0].pose;

// Calculate the distance between the two hands
let leftHand = pose.leftWrist;
let rightHand = pose.rightWrist;
let distance = dist(leftHand.x, leftHand.y, rightHand.x, rightHand.y);

// Calculate the number of doubletaps
let leftBall = pose.leftAnkle;
let rightBall = pose.rightAnkle;
let leftBarlet = leftBall.x - barletWidth / 2;
let rightBarlet = rightBall.x - barletWidth / 2;
let doubletapLeft = abs(leftBarlet - leftHand.x) < doubletapThreshold && abs(leftBall.y - leftHand.y) < ballDiameter / 2;
let doubletapRight = abs(rightBarlet - rightHand.x) < doubletapThreshold && abs(rightBall.y - rightHand.y) < ballDiameter / 2;
if (doubletapLeft || doubletapRight) {
doubletapCount++;
}

// Calculate the number of tricks
let leftElbow = pose.leftElbow;
let rightElbow = pose.rightElbow;
let elbowDistance = dist(leftElbow.x, leftElbow.y, rightElbow.x, rightElbow.y);
if (distance < elbowDistance / 2 && doubletapCount > 1) {
trickCount++;
}

// Calculate the dribble time
dribbleTime += deltaTime;
}

// Display the results
textSize(32);
fill(255, 0, 0);
text("Doubletaps: " + doubletapCount, 10, 40);
text("Tricks: " + trickCount, 10, 80);
text("Time: " + (dribbleTime / 1000).toFixed(2) + " seconds", 10, 120);

// Display error messages
if (video.elt.paused || video.elt.readyState < 3) {
errorDiv.html("Error: Webcam not availableor not allowed");
errorDiv.show();
} else if (poses.length === 0) {
errorDiv.html("Error: No pose detected");
errorDiv.show();
} else {
errorDiv.hide();
}
}